package com.example.lmy.customview.FragmentViewPager;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.example.lmy.customview.R;
import com.google.gson.Gson;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/**
 * @功能:
 * @Creat 2019/03/22 11:46
 * @User Lmy
 * @By Android Studio
 */
public class Fragment1 extends BaseFragment {
    private View view;
    /**
     * 标志位，标志已经初始化完成
     */
    private boolean isPrepared;

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        // 配置setUserVisibleHint（）方法
        setUserVisibleHint(true);
        super.onActivityCreated(savedInstanceState);
    }


    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment1_layout, container, false);
        initViews(view);
        isPrepared = true;
        return view;
    }

    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);
        //可见的并且是初始化之后才加载
        if (isPrepared && isVisibleToUser) {
            //处理数据
        }
    }


    public void initViews(View view) {
    }

}

