package com.example.lmy.customview.Utils;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.util.Log;

/**
 * 功能:
 * 版本控制
 *
 * @author :limingyang
 * @create ：2019/5/6 10:49
 * @created by android studiuo
 */
public class VersionControl {
    private Context context;
    private final String VERSION_CODE = "VersionCode";
    private String dialog_tible = "更新提示";
    private String dialog_affirm = "立即更新";
    private String dialog_cancel = "以后更新";

    public VersionControl(Context context) {
        this.context = context;
    }

    /**
     * 版本升级，带拒绝后不会弹出功能的对话框
     *
     * @param nVersion 最新的版本号
     * @param message  升级的内容
     * @param url      apk文件的url
     */
    public void updateRecordVersionDialog(final int nVersion, String message, final String url) {
        final SaveDataUtils saveData = new SaveDataUtils((Activity) context, SaveDataUtils.SAVE_VERSION);
        int saveVersion = saveData.getInt(VERSION_CODE, getAppVersionCode(context));
        saveData.setInt(VERSION_CODE, getAppVersionCode(context));
        if (nVersion > saveVersion) {
            AlertDialog.Builder builder = new AlertDialog.Builder(context);
            builder.setCancelable(false);
            builder.setTitle(dialog_tible);
            builder.setMessage(message);
            builder.setPositiveButton(dialog_affirm, new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int which) {
                    saveData.setInt(VERSION_CODE, nVersion);
                    saveData.commit();
                    dialog.dismiss();
                    startDownload(url);
                }
            });
            builder.setNegativeButton(dialog_cancel, new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int which) {
                    saveData.setInt(VERSION_CODE, nVersion);
                    saveData.commit();
                    dialog.dismiss();
                }
            });
            builder.create().show();
        }

    }

    /**
     * 版本升级对话框
     *
     * @param message 升级的内容
     * @param url     apk文件的url
     */
    public void updateVersionDialog(String message, final String url) {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setCancelable(false);
        builder.setTitle(dialog_tible);
        builder.setMessage(message);
        builder.setPositiveButton(dialog_affirm, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
                startDownload(url);
            }
        });
        builder.setNegativeButton(dialog_cancel, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });
        builder.create().show();
    }


    private void startDownload(String url) {
        Intent intent = new Intent(context, DownLoadService.class);
        intent.putExtra(DownLoadService.KEY_URL_SIGN, url);
        context.startService(intent);
    }


    /**
     * 返回当前程序版本号
     */
    public int getAppVersionCode(Context context) {
        int versioncode = 0;
        try {
            versioncode = getVersionInformation(context).versionCode;
        } catch (Exception e) {
            Log.e("VersionInfo", "Exception", e);
        }
        return versioncode;
    }

    /**
     * 返回当前程序版本名
     */
    public String getAppVersionName(Context context) {
        String versionName = null;
        try {
            versionName = getVersionInformation(context).versionName;
        } catch (Exception e) {
            Log.e("VersionInfo", "Exception", e);
        }
        return versionName;
    }

    /**
     * 本软件的版本信息
     *
     * @return
     */
    private PackageInfo getVersionInformation(Context context) throws PackageManager.NameNotFoundException {
        PackageManager pm = context.getPackageManager();
        PackageInfo pi = pm.getPackageInfo(context.getPackageName(), 0);
        return pi;
    }


}
