package com.example.lmy.customview.BGAPhotoPicker.activity;


import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.example.lmy.customview.Activity.BaseActivity;
import com.example.lmy.customview.BGAPhotoPicker.utils.BGAPhotoPickerUtils;
import com.example.lmy.customview.R;

import java.util.ArrayList;

import cn.bingoogolapple.photopicker.activity.BGAPhotoPickerActivity;
import cn.bingoogolapple.photopicker.activity.BGAPhotoPickerPreviewActivity;
import cn.bingoogolapple.photopicker.widget.BGASortableNinePhotoLayout;


/**
 * 你自己项目里「可以不继承 BGAPPToolbarActivity」，我在这里继承 BGAPPToolbarActivity 只是为了方便写 Demo
 */
public class BGAPickerActivity extends BaseActivity implements View.OnClickListener {
    private TextView tvTo;
    private ImageView ivShow;
    ArrayList<String> mPicList = new ArrayList<>();
    private TextView tvGetfile;


    /**
     * 拖拽排序九宫格控件
     */
    private BGASortableNinePhotoLayout mPhotosSnpl;

    public static void show(Context context) {
        context.startActivity(new Intent(context, BGAPickerActivity.class));
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.bgapicker);
        initView();
    }

    protected void initView() {
        mPhotosSnpl = findViewById(R.id.snpl_moment_add_photos);
        tvTo = findViewById(R.id.tv_to);
        ivShow = findViewById(R.id.iv_show);
        tvGetfile = findViewById(R.id.tv_getfile);
        BGAPhotoPickerUtils.getInstance().init(BGAPickerActivity.this, mPhotosSnpl, 9, 3, BGAPhotoPickerUtils.RC_CHOOSE_PHOTO);
    }

    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.tv_moment_add_choice_photo:
                BGAPhotoPickerUtils.getInstance().MultipleChoice(BGAPickerActivity.this);
                break;
            case R.id.tv_to:
                BGANinePhotoActivity.show(BGAPickerActivity.this);
                break;
            case R.id.tv_getfile:
                Log.d("GetData imageFile", BGAPhotoPickerUtils.getInstance().getFile().toString());
                String push = "content://";

                break;
        }
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK && requestCode == BGAPhotoPickerUtils.RC_CHOOSE_PHOTO) {
            mPhotosSnpl.addMoreData(BGAPhotoPickerActivity.getSelectedPhotos(data));//设置多选数据
        } else if (requestCode == BGAPhotoPickerUtils.RC_PHOTO_PREVIEW) {
            //拍照返回的数据 也属于单选
            mPhotosSnpl.setData(BGAPhotoPickerPreviewActivity.getSelectedPhotos(data));//设置单选数据
        } else if (requestCode == BGAPhotoPickerUtils.MULTIPLECHOICE) {
            //单选时返回的数据
            if (data == null) {
                Toast.makeText(this, "未选择图片", Toast.LENGTH_SHORT).show();
            } else {
                Glide.with(this).load(BGAPhotoPickerActivity.getSelectedPhotos(data).get(0)).into(ivShow);
            }
        }
    }
}


