package com.example.lmy.customview.Activity;

import android.app.DownloadManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.support.v4.content.FileProvider;
import android.support.v4.content.LocalBroadcastManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.webkit.MimeTypeMap;
import android.widget.Button;
import android.widget.Toast;

import com.example.lmy.customview.BuildConfig;
import com.example.lmy.customview.CustomView.MyDialog;
import com.example.lmy.customview.OkHttp.HttpRequestUtils;
import com.example.lmy.customview.OkHttp.JsonUtils;
import com.example.lmy.customview.OkHttp.OkHttp3NetWork;
import com.example.lmy.customview.OkHttp.OnNetWorkInterface;
import com.example.lmy.customview.OkHttp.SubmitData;
import com.example.lmy.customview.R;

import org.json.JSONObject;

import java.io.File;

public class UpDataActivity extends BaseActivity {
    private Button updata;
    private String url = "http://p.gdown.baidu.com/7bd8f308e049f681982e965ffff4c2c2f45392abbd53c969b22ffb815f54dec8053e46e9649cad9f389c1e6cb343cee8d02bcd2bad37568fe4015b415c086d746599287211cb1db4ed4cc9d2844733bb7b2ef121667e8bf953c05b526b1944d8fe140077803033a60275df73ca432516dd2d5d6551266c498e6d4c8a3ef9b2d413809f8c37646b6b440157c450d23cc3749b2827cd629b7fc87e131043081dea4ee5a3b21ec64e35b9f39b4e5a8b5c6cf099a6d7942b74cbf4bbd3f45ef9e2ca21e766669e49b2af7f06c8b66255786b";


//清单文件中注册DownloadService 并添加相关权限注册 一定要注意权限
     /*
     <provider
    android:name="android.support.v4.content.FileProvider"
    android:authorities="com.example.lmy.customview.fileprovider"
    android:exported="false"
    android:grantUriPermissions="true">
            <meta-data
    android:name="android.support.FILE_PROVIDER_PATHS"
    android:resource="@xml/file_paths" />
        </provider>
        provider注册和文件
        **/

    public static void show(Context context) {
        context.startActivity(new Intent(context, UpDataActivity.class));
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_up_data);
        updata = findViewById(R.id.updata);
        updata.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent serviceIntent = new Intent(UpDataActivity.this, DownloadService.class);
                serviceIntent.setData(Uri.parse(url));
                startService(serviceIntent);
                OkHttp3NetWork.submitDialog(UpDataActivity.this, HttpRequestUtils.REQUEST_GET, new OnNetWorkInterface() {
                    @Override
                    public boolean validate() {
                        return true;
                    }

                    @Override
                    public SubmitData getSubmitData() {
                        SubmitData submitData = new SubmitData("http://192.168.1.87:9090/app/commons/updateVersions?sysType=0&platform=1");
                        return submitData;
                    }

                    @Override
                    public void result(String result) {
                        Log.d("GetData", result);
                        JsonUtils.processStringResult(result, null, UpDataActivity.this, new JsonUtils.OnProcessStringListener() {
                            @Override
                            public void onSucceed(String data) throws Exception {
                                JSONObject jsonObject = new JSONObject(data).getJSONObject("data");
                                if (jsonObject.getJSONObject("updateVersion").getString("versionNo").equals(String.valueOf(getVersion()))) {
                                    Toast.makeText(UpDataActivity.this, "当前已是最新版本", Toast.LENGTH_SHORT).show();
                                } else if (2 > getVersion()) {

                                } else {
                                    Toast.makeText(UpDataActivity.this, "啦啦啦", Toast.LENGTH_SHORT).show();
                                }
                            }
                            @Override
                            public void onFailure(String error) {

                            }
                        });


                    }
                });


            }
        });

    }
    public int getVersion() {
        PackageInfo pkg;
        int versionCode = 0;
        String versionName = "";
        try {
            pkg = this.getPackageManager().getPackageInfo(this.getApplication().getPackageName(), 0);
            versionCode = pkg.versionCode;

        } catch (PackageManager.NameNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return versionCode;
    }

}
