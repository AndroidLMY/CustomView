package com.example.lmy.customview.OkHttp;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import com.example.lmy.customview.Activity.BaseActivity;
import com.example.lmy.customview.R;

import java.io.IOException;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.Headers;
import okhttp3.Interceptor;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.internal.http.HttpHeaders;

public class OkHttpTestActivity extends BaseActivity implements View.OnClickListener {
    private Button bt01;
    private Button bt02;
    private Button bt03;
    private Button bt04;
    private Button bt05;


    public static void show(Context context) {
        context.startActivity(new Intent(context, OkHttpTestActivity.class));
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ok_http_test);
        bt01 = findViewById(R.id.bt_01);
        bt02 = findViewById(R.id.bt_02);
        bt03 = findViewById(R.id.bt_03);
        bt04 = findViewById(R.id.bt_04);
        bt05 = findViewById(R.id.bt_05);
        bt01.setOnClickListener(this);
        bt02.setOnClickListener(this);
        bt03.setOnClickListener(this);
        bt04.setOnClickListener(this);
        bt05.setOnClickListener(this);


    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.bt_01:
            OkHttp3NetWork.submitDialog(OkHttpTestActivity.this, HttpRequestUtils.REQUEST_GET, new OnNetWorkInterface() {
                    @Override
                    public boolean validate() {
                        return true;
                    }
                    @Override
                    public SubmitData getSubmitData() {
                        SubmitData submitData = new SubmitData("");
                        return submitData;
                    }

                    @Override
                    public void result(String result) {

                    }
                });

                break;
            case R.id.bt_02:

                break;
            case R.id.bt_03:

                break;
            case R.id.bt_04:

                break;
            case R.id.bt_05:

                break;
        }
    }


}
