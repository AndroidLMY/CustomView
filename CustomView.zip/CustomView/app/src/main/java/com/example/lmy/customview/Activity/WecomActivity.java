package com.example.lmy.customview.Activity;

import android.os.Bundle;

import com.example.lmy.customview.GuidePage.GuideActivity;
import com.example.lmy.customview.GuidePage.WelcomeActivity;
import com.example.lmy.customview.R;
import com.example.lmy.customview.RecyclerViewAddTitle.activity.RecyclerViewActivity;
import com.squareup.haha.perflib.Main;

/**
 * Creat 20190218 14:49
 * User Lmy
 * By AndroidStudio
 */
public class WecomActivity extends WelcomeActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.welcome);

    }

    @Override
    public void goGuide() {
        GuideActivity.show(this,10 ,new int[]{
                R.mipmap.startimage,
                R.mipmap.startimage,
                R.mipmap.startimage,
                R.mipmap.startimage,
                R.mipmap.startimage
        }, MainActivity.class);

    }

    @Override
    public void goMain() {
        MainActivity.show(this);
        finish();
    }
}

