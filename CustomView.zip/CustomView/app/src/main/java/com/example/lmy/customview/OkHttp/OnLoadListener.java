package com.example.lmy.customview.OkHttp;

/**
 * @功能:
 * @Creat 2019/04/30 10:33
 * @User Lmy
 * @By Android Studio
 */

/**
 * @author：zhangerpeng 版本：
 * 日期：2019\2\15 0015
 * 描述：
 * 加载弹框接口
 */
public interface OnLoadListener {
    void onShow();

    void onConceal();
}
