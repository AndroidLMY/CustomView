package com.example.lmy.customview.RecyclerviewCheck;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.example.lmy.customview.R;

import java.util.ArrayList;
import java.util.List;


/**
 * Created by guohao on 2017/9/6.
 */

public class CheckRecyclerViewAdapter extends RecyclerView.Adapter<CheckRecyclerViewAdapter.ViewHolder> {
    private static final int CHECK = 0;//表示不可编辑状态
    int mEditMode = CHECK;
    private Context context;
    private List<MyLiveList> mMyLiveList;
    private OnItemClickListener mOnItemClickListener;

    public CheckRecyclerViewAdapter(Context context,List<MyLiveList> myLiveList) {
        this.context = context;
        this.mMyLiveList = myLiveList;

    }



    public List<MyLiveList> getMyLiveList() {
        if (mMyLiveList == null) {
            mMyLiveList = new ArrayList<>();
        }
        return mMyLiveList;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_my_live, parent, false);
        ViewHolder holder = new ViewHolder(view);
        return holder;
    }

    @Override
    public int getItemCount() {
        return mMyLiveList.size();
    }

    @Override
    public void onBindViewHolder(final ViewHolder holder, final int position) {
        final MyLiveList myLive = mMyLiveList.get(holder.getAdapterPosition());
        holder.tvSource.setText(myLive.getSource());
        if (mEditMode == CHECK) {
            //不可编辑状态下不显示checkBox按钮
            holder.checkBox.setVisibility(View.GONE);
        } else {
            //可编辑的状态显示checkBox按钮
            holder.checkBox.setVisibility(View.VISIBLE);
            if (myLive.isSelect()) {
                //根据每条数据中的isSelect状态值谈定是否被选中 如果选中就设置选中状态的图标
                holder.checkBox.setImageResource(R.drawable.ic_checked);
            } else {
                holder.checkBox.setImageResource(R.drawable.ic_uncheck);
            }
        }
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //item的点击事件
                mOnItemClickListener.onItemClickListener(holder.getAdapterPosition(), mMyLiveList);
            }
        });
        holder.itemView.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                //item的长按事件回调
                onLongClistenner.OnLongClickner();
                return false;
            }
        });
    }


    public void setEditMode(int editMode) {
        //用于标识是否要显示checkBox的功能
        mEditMode = editMode;
        notifyDataSetChanged();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {

        private LinearLayout item;
        private ImageView checkBox;
        private RelativeLayout rootView;
        private TextView tvSource;

        public ViewHolder(View itemView) {
            super(itemView);
            item = itemView.findViewById(R.id.item);
            checkBox = itemView.findViewById(R.id.check_box);
            rootView = itemView.findViewById(R.id.root_view);
            tvSource = itemView.findViewById(R.id.tv_source);

        }
    }


    public OnLongClistenner onLongClistenner;

    public void setOnLongner(OnLongClistenner onLongner) {
        this.onLongClistenner = onLongner;
    }

    public interface OnLongClistenner {
        public void OnLongClickner();
    }

    public void setOnItemClickListener(OnItemClickListener onItemClickListener) {
        this.mOnItemClickListener = onItemClickListener;
    }

    public interface OnItemClickListener {
        void onItemClickListener(int pos, List<MyLiveList> myLiveList);
    }
}
