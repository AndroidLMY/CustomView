package com.example.lmy.customview.MPChart.Activity;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.example.lmy.customview.R;
import com.example.lmy.customview.MPChart.Bean.Type;
import com.example.lmy.customview.MPChart.Utils.CustomViewHBarchartUtils;
import com.example.lmy.customview.MPChart.Utils.HBarchartUtils;
import com.github.mikephil.charting.charts.HorizontalBarChart;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
/**
 * 功能:
 * 横向柱状图
 * @author :limingyang
 * @create ：2019/5/23 13:01
 * @created by android studiuo
 */

public class CrosswiseActivity extends AppCompatActivity {
    private LinearLayout container;
    View itemView;
    private HorizontalBarChart horizontalBarChart;
    private List<Type> typeList;
    private double maxScale = 0;
    int color = Color.parseColor("#30A5FF");
    private ImageView ivBack;
    private TextView tvTitle;

    public static void show(Context context) {
        context.startActivity(new Intent(context, CrosswiseActivity.class));
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_double_histogram_h);
        container = findViewById(R.id.container);
        horizontalBarChart = findViewById(R.id.chart1);
        itemView = getWindow().getDecorView();

        ivBack = findViewById(R.id.iv_back);
        tvTitle = findViewById(R.id.tv_title);
        ivBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        tvTitle.setText("横向柱状图");


        HBarchartUtils.getInstance().initBarChart(this, horizontalBarChart);
        initData();
        CustomViewHBarchartUtils.getInstance().initChart(itemView, container, typeList, color, maxScale);
    }

    private void initData() {
        typeList = new ArrayList<>();
        int min = 0;
        int max = 100;
        Random random = new Random();
        int all = 0;
        for (int i = 0; i < 10; i++) {
            Type type = new Type();
            type.setTypeName("上海红田温县工厂" + i);
            int sale = random.nextInt(max) % (max - min + 1) + min;
            type.setSale(sale);
            all = all + sale;
            typeList.add(type);
            //这个循环初始化销量和标题 用all计算所有销量的总和
        }
        for (int i = 0; i < 10; i++) {
            double typeScale = (double) typeList.get(i).getSale() / all;
            typeList.get(i).setTypeScale(typeScale);
            //取出每一项中的销量除以总销量得出百分占比
        }
        for (int i = 0; i < typeList.size(); i++) {
            if (typeList.get(i).getTypeScale() > maxScale)
                maxScale = typeList.get(i).getTypeScale();
        }
    }
}
