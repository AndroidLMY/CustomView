package com.example.lmy.customview.MPChart.Activity;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.lmy.customview.R;
import com.example.lmy.customview.MPChart.Utils.BarChartUtils;
import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.data.BarEntry;

import java.util.ArrayList;

/**
 * 功能:
 * 堆积柱状图 自定义x轴数据 和图例
 *
 * @author :limingyang
 * @create ：2019/5/23 13:05
 * @created by android studiuo
 */
public class HeapUpBarchartActivity extends AppCompatActivity {
    private BarChart chart;
    private int[] arr = {0xFFDB2C1F, 0xFFFE9400, 0xFF33A8FF};
    ArrayList<BarEntry> barEntries = new ArrayList<>();
    ArrayList<String> mnamelist = new ArrayList<>();

    private ImageView ivBack;
    private TextView tvTitle;

    public static void show(Context context) {
        context.startActivity(new Intent(context, HeapUpBarchartActivity.class));
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_heap_barchart);
        chart = findViewById(R.id.chart1);
        ivBack = findViewById(R.id.iv_back);
        tvTitle = findViewById(R.id.tv_title);
        ivBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        tvTitle.setText("堆积柱状图");
        for (int i = 1; i <= 12; i++) {
            barEntries.add(new BarEntry(i, new float[]{
                    new Double(Math.random() * 30).intValue(),
                    new Double(Math.random() * 30).intValue(),
                    new Double(Math.random() * 30).intValue()}));
        }
        for (int i = 1; i <= 12; i++) {
            mnamelist.add("A" + i);
        }
        BarChartUtils.getInstance().InitBarHeapChart(this, chart, barEntries, mnamelist, arr, 7);

    }


}
