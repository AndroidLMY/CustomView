package com.example.lmy.customview.RecyclerviewCheck;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.example.lmy.customview.Activity.BaseActivity;
import com.example.lmy.customview.R;

import java.util.ArrayList;
import java.util.List;

public class CheckActivity extends BaseActivity implements View.OnClickListener, CheckRecyclerViewAdapter.OnItemClickListener {
    private TextView btnEditor;
    private RecyclerView recyclerview;
    private LinearLayout llMycollectionBottomDialog;
    private TextView tv;
    private TextView tvSelectNum;
    private Button btnDelete;
    private TextView selectAll;
    private static final int CHECK = 0;
    private static final int EDIT = 1;

    private CheckRecyclerViewAdapter mRadioAdapter = null;
    private LinearLayoutManager mLinearLayoutManager;
    private List<MyLiveList> mList = new ArrayList<>();
    private int mEditMode = CHECK;
    private boolean isSelectAll = false;
    private boolean editorStatus = false;
    private int index = 0;//用于记录选中item的个数

    public static void show(Context context) {
        context.startActivity(new Intent(context, CheckActivity.class));
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_check);
        btnEditor = findViewById(R.id.btn_editor);
        recyclerview = findViewById(R.id.recyclerview);
        llMycollectionBottomDialog = findViewById(R.id.ll_mycollection_bottom_dialog);
        tv = findViewById(R.id.tv);
        tvSelectNum = findViewById(R.id.tv_select_num);
        btnDelete = findViewById(R.id.btn_delete);
        selectAll = findViewById(R.id.select_all);
        initData();
        initListener();
    }


    public void initData() {
        init();//初始化数据
        mRadioAdapter = new CheckRecyclerViewAdapter(this, mList);
        mLinearLayoutManager = new LinearLayoutManager(this);
        recyclerview.setLayoutManager(mLinearLayoutManager);
        recyclerview.setAdapter(mRadioAdapter);//设置adapter

        mRadioAdapter.setOnLongner(new CheckRecyclerViewAdapter.OnLongClistenner() {
            @Override
            public void OnLongClickner() {
                updataEditMode();
            }
        });
    }

    /**
     * 功能:
     * 初始化数据
     *
     * @author :limingyang
     * @create ：2019/3/16 19:33
     * @created by android studiuo
     */
    public void init() {
        for (int i = 0; i < 30; i++) {
            MyLiveList myLiveList = new MyLiveList();
            myLiveList.setTitle("这是第" + i + "个条目");
            myLiveList.setSource("来源" + i);
            mList.add(myLiveList);
        }
    }

    /**
     * 根据选择的数量是否为0来判断按钮的是否可点击.或者判断底部布局是否显示
     *
     * @param size
     */
    private void setBtnBackground(int size) {
        if (size != 0) {
            btnDelete.setBackgroundResource(R.drawable.button_shape);
            btnDelete.setEnabled(true);
            btnDelete.setTextColor(Color.WHITE);
        } else {
            btnDelete.setBackgroundResource(R.drawable.button_noclickable_shape);
            btnDelete.setEnabled(false);
            btnDelete.setTextColor(ContextCompat.getColor(this, R.color.colorAccent));
        }
    }

    public void initListener() {
        mRadioAdapter.setOnItemClickListener(this);
        btnDelete.setOnClickListener(this);
        selectAll.setOnClickListener(this);
        btnEditor.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btn_delete:
                deleteVideo();
                break;
            case R.id.select_all:
                selectAllMain();
                break;
            case R.id.btn_editor:
                updataEditMode();
                break;
            default:
                break;
        }
    }

    /**
     * 全选和反选
     */
    private void selectAllMain() {
        if (mRadioAdapter == null) return;
        if (!isSelectAll) {
            for (int i = 0, j = mRadioAdapter.getMyLiveList().size(); i < j; i++) {
                mRadioAdapter.getMyLiveList().get(i).setSelect(true);
            }
            index = mRadioAdapter.getMyLiveList().size();
            btnDelete.setEnabled(true);
            selectAll.setText("取消全选");
            isSelectAll = true;
        } else {
            for (int i = 0, j = mRadioAdapter.getMyLiveList().size(); i < j; i++) {
                mRadioAdapter.getMyLiveList().get(i).setSelect(false);
            }
            index = 0;
            btnDelete.setEnabled(false);
            selectAll.setText("全选");
            isSelectAll = false;
        }
        mRadioAdapter.notifyDataSetChanged();
        setBtnBackground(index);
        tvSelectNum.setText(String.valueOf(index));
    }

    /**
     * 删除逻辑
     */
    private void deleteVideo() {
        if (index == 0) {
            btnDelete.setEnabled(false);
            return;
        }
        final AlertDialog builder = new AlertDialog.Builder(this)
                .create();
        builder.show();
        if (builder.getWindow() == null) return;
        builder.getWindow().setContentView(R.layout.pop_user);//设置弹出框加载的布局
        TextView msg = (TextView) builder.findViewById(R.id.tv_msg);
        Button cancle = (Button) builder.findViewById(R.id.btn_cancle);
        Button sure = (Button) builder.findViewById(R.id.btn_sure);
        if (msg == null || cancle == null || sure == null) return;
        if (index == 1) {
            msg.setText("删除后不可恢复，是否删除该条目？");
        } else {
            msg.setText("删除后不可恢复，是否删除这" + index + "个条目？");
        }
        cancle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                builder.dismiss();
            }
        });
        sure.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                List<String> dstr = new ArrayList<>();
                for (int i = mRadioAdapter.getMyLiveList().size(), j = 0; i > j; i--) {
                    MyLiveList myLive = mRadioAdapter.getMyLiveList().get(i - 1);
                    if (myLive.isSelect()) {
                        mRadioAdapter.getMyLiveList().remove(myLive);
                        dstr.add(myLive.getTitle());
                        index--;
                        //在这里声明一个数组 存放将要删除的id
                    }
                }
                Log.d("GetData", dstr.toString());
                index = 0;
                tvSelectNum.setText(String.valueOf(0));
                setBtnBackground(index);
                if (mRadioAdapter.getMyLiveList().size() == 0) {
                    llMycollectionBottomDialog.setVisibility(View.GONE);
                }
                mRadioAdapter.notifyDataSetChanged();
                builder.dismiss();
            }
        });
    }

    private void updataEditMode() {
        mEditMode = mEditMode == CHECK ? EDIT : CHECK;
        if (mEditMode == EDIT) {
            btnEditor.setText("取消");
            for (int i = 0; i < mRadioAdapter.getMyLiveList().size(); i++) {
                mRadioAdapter.getMyLiveList().get(i).setSelect(false);
                //设置点击取消编辑之后所有item的状态设置为选中
            }
            llMycollectionBottomDialog.setVisibility(View.VISIBLE);
            editorStatus = true;
        } else {
            btnEditor.setText("编辑");
            llMycollectionBottomDialog.setVisibility(View.GONE);
            editorStatus = false;
            clearAll();
        }
        mRadioAdapter.setEditMode(mEditMode);
    }

    private void clearAll() {
        tvSelectNum.setText(String.valueOf(0));
        isSelectAll = false;
        selectAll.setText("全选");
        setBtnBackground(0);
    }

    @Override
    public void onItemClickListener(int pos, List<MyLiveList> myLiveList) {
        if (editorStatus) {
            MyLiveList myLive = myLiveList.get(pos);
            boolean isSelect = myLive.isSelect();
            if (!isSelect) {
                index++;
                myLive.setSelect(true);
                if (index == myLiveList.size()) {
                    isSelectAll = true;
                    selectAll.setText("取消全选");
                }
            } else {
                myLive.setSelect(false);
                index--;
                isSelectAll = false;
                selectAll.setText("全选");
            }
            setBtnBackground(index);
            tvSelectNum.setText(String.valueOf(index));
            mRadioAdapter.notifyDataSetChanged();
        }
    }
}
