package com.example.lmy.customview.MPChart.Activity;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.lmy.customview.R;
import com.example.lmy.customview.MPChart.Utils.CombinedChartManager;
import com.github.mikephil.charting.charts.CombinedChart;

import java.util.ArrayList;
import java.util.List;

/**
 * 功能:
 * 组合图
 *
 * @author :limingyang
 * @create ：2019/5/22 9:18
 * @created by android studiuo
 */
public class CombinationActivity extends AppCompatActivity {
    private CombinedChart combinedChart;
    private ImageView ivBack;
    private TextView tvTitle;

    public static void show(Context context) {
        context.startActivity(new Intent(context, CombinationActivity.class));
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_combination);
        combinedChart = findViewById(R.id.combinedChart);
        ivBack = findViewById(R.id.iv_back);
        tvTitle = findViewById(R.id.tv_title);
        ivBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        tvTitle.setText("组合图");
        //x轴数据
        List<String> xData = new ArrayList<>();
        xData.add("5.6");
        xData.add("5.7");
        xData.add("5.8");
        xData.add("5.9");
        xData.add("5.10");
        xData.add("5.11");
        xData.add("5.12");
        xData.add("5.13");
        xData.add("5.14");
        xData.add("5.15");
        //BarChart y轴数据集合
        List<Float> BarData = new ArrayList<>();
        for (int j = 0; j < 10; j++) {
            BarData.add((float) (Math.random() * 50));
        }
        //LineChart y轴数据集合
        List<Float> LineyData = new ArrayList<>();

        for (int j = 0; j < 10; j++) {
            LineyData.add((float) (Math.random() * 50 + 51));
        }
        //管理类
        CombinedChartManager combineChartManager = new CombinedChartManager(this, combinedChart);
        combineChartManager.showCombinedChart(
                xData,
                BarData,
                LineyData,
                "发货单",
                "包裹数",
                0xFF33C25E,
                0xFF33A8FF);
    }
}
