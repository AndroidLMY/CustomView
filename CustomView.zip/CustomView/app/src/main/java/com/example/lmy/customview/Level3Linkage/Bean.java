package com.example.lmy.customview.Level3Linkage;

import java.util.List;

/**
 * @功能:
 * @Creat 2019/04/29 16:24
 * @User Lmy
 * @By Android Studio
 */
public class Bean {

    /**
     * code : 200
     * data : {"dataList":[],"report":{"income":0,"balance":801465,"outlay":0},"funds":[{"hasChild":"1","name":"收入","id":"1","items":[{"hasChild":"0","name":"手工录入货款","id":11},{"hasChild":"0","name":"手工录入货款及利息","id":12},{"hasChild":"0","name":"借款","id":13},{"hasChild":"0","name":"其他","id":14}]},{"name":"支出","id":"2","items":[{"hasChild":"0","name":"供应商付款","id":21},{"hasChild":"0","name":"经销商货物退款","id":22},{"hasChild":"0","name":"还借款","id":23},{"hasChild":"0","name":"购买资产","id":24},{"hasChild":"1","name":"消耗类支出","id":25,"items":[{"hasChild":"0","name":"消耗类支出","id":25},{"hasChild":"0","name":"消耗类支出","id":25},{"hasChild":"0","name":"消耗类支出","id":25}]},{"hasChild":"0","name":"其他","id":26},{"hasChild":"0","name":"财务费","id":27}]}]}
     */

    private String code;
    private DataBean data;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public DataBean getData() {
        return data;
    }

    public void setData(DataBean data) {
        this.data = data;
    }

    public static class DataBean {
        /**
         * dataList : []
         * report : {"income":0,"balance":801465,"outlay":0}
         * funds : [{"hasChild":"1","name":"收入","id":"1","items":[{"hasChild":"0","name":"手工录入货款","id":11},{"hasChild":"0","name":"手工录入货款及利息","id":12},{"hasChild":"0","name":"借款","id":13},{"hasChild":"0","name":"其他","id":14}]},{"name":"支出","id":"2","items":[{"hasChild":"0","name":"供应商付款","id":21},{"hasChild":"0","name":"经销商货物退款","id":22},{"hasChild":"0","name":"还借款","id":23},{"hasChild":"0","name":"购买资产","id":24},{"hasChild":"1","name":"消耗类支出","id":25,"items":[{"hasChild":"0","name":"消耗类支出","id":25},{"hasChild":"0","name":"消耗类支出","id":25},{"hasChild":"0","name":"消耗类支出","id":25}]},{"hasChild":"0","name":"其他","id":26},{"hasChild":"0","name":"财务费","id":27}]}]
         */

        private ReportBean report;
        private List<?> dataList;
        private List<FundsBean> funds;

        public ReportBean getReport() {
            return report;
        }

        public void setReport(ReportBean report) {
            this.report = report;
        }

        public List<?> getDataList() {
            return dataList;
        }

        public void setDataList(List<?> dataList) {
            this.dataList = dataList;
        }

        public List<FundsBean> getFunds() {
            return funds;
        }

        public void setFunds(List<FundsBean> funds) {
            this.funds = funds;
        }

        public static class ReportBean {
            /**
             * income : 0
             * balance : 801465
             * outlay : 0
             */

            private int income;
            private int balance;
            private int outlay;

            public int getIncome() {
                return income;
            }

            public void setIncome(int income) {
                this.income = income;
            }

            public int getBalance() {
                return balance;
            }

            public void setBalance(int balance) {
                this.balance = balance;
            }

            public int getOutlay() {
                return outlay;
            }

            public void setOutlay(int outlay) {
                this.outlay = outlay;
            }
        }

        public static class FundsBean {
            /**
             * hasChild : 1
             * name : 收入
             * id : 1
             * items : [{"hasChild":"0","name":"手工录入货款","id":11},{"hasChild":"0","name":"手工录入货款及利息","id":12},{"hasChild":"0","name":"借款","id":13},{"hasChild":"0","name":"其他","id":14}]
             */

            private String hasChild;
            private String name;
            private String id;
            private List<ItemsBean> items;

            public String getHasChild() {
                return hasChild;
            }

            public void setHasChild(String hasChild) {
                this.hasChild = hasChild;
            }

            public String getName() {
                return name;
            }

            public void setName(String name) {
                this.name = name;
            }

            public String getId() {
                return id;
            }

            public void setId(String id) {
                this.id = id;
            }

            public List<ItemsBean> getItems() {
                return items;
            }

            public void setItems(List<ItemsBean> items) {
                this.items = items;
            }

            public static class ItemsBean {
                /**
                 * hasChild : 0
                 * name : 手工录入货款
                 * id : 11
                 */

                private String hasChild;
                private String name;
                private int id;

                public String getHasChild() {
                    return hasChild;
                }

                public void setHasChild(String hasChild) {
                    this.hasChild = hasChild;
                }

                public String getName() {
                    return name;
                }

                public void setName(String name) {
                    this.name = name;
                }

                public int getId() {
                    return id;
                }

                public void setId(int id) {
                    this.id = id;
                }
            }
        }
    }
}
