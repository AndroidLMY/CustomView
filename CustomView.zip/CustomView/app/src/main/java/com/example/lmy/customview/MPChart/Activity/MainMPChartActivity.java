package com.example.lmy.customview.MPChart.Activity;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;


import com.example.lmy.customview.Activity.BaseActivity;
import com.example.lmy.customview.R;

public class MainMPChartActivity extends BaseActivity implements View.OnClickListener {

    private Button bt01;
    private Button bt02;
    private Button bt03;
    private Button bt04;
    private Button bt05;
    private Button bt06;
    private Button bt07;
    private Button bt08;
    private ImageView ivBack;
    private TextView tvTitle;

    public static void show(Context context) {
        context.startActivity(new Intent(context, MainMPChartActivity.class));
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_statistics);
        initViews();
    }

    @Override
    public void initViews() {
        bt01 = findViewById(R.id.bt_01);
        bt02 = findViewById(R.id.bt_02);
        bt03 = findViewById(R.id.bt_03);
        bt04 = findViewById(R.id.bt_04);
        bt05 = findViewById(R.id.bt_05);
        bt06 = findViewById(R.id.bt_06);
        bt07 = findViewById(R.id.bt_07);
        bt08 = findViewById(R.id.bt_08);
        ivBack = findViewById(R.id.iv_back);
        tvTitle = findViewById(R.id.tv_title);
        initData();
    }

    @Override
    public void initData() {
        tvTitle.setText("三方统计View控件");
        initListener();
    }

    @Override
    public void initListener() {
        bt01.setOnClickListener(this);
        bt02.setOnClickListener(this);
        bt03.setOnClickListener(this);
        bt04.setOnClickListener(this);
        bt05.setOnClickListener(this);
        bt06.setOnClickListener(this);
        bt07.setOnClickListener(this);
        bt08.setOnClickListener(this);
        ivBack.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.bt_01:
                //饼状图
                PieChartActivity.show(this);
                break;
            case R.id.bt_02:
                //柱形图
                BarChartActivity.show(this);
                break;
            case R.id.bt_03:
                //环形进度
                CircleProgressActivity.show(this);
                break;
            case R.id.bt_04:
                //折线图
                LineChartActivity.show(this);
                break;
            case R.id.bt_05:
                //组合图
                CombinationActivity.show(this);
                break;
            case R.id.bt_06:
                //横向柱状图
                CrosswiseActivity.show(this);
                break;
            case R.id.bt_07:
                //堆积柱状图
                HeapUpBarchartActivity.show(this);
                break;
            case R.id.bt_08:
                //recyclerview堆积图
                RecyclerViewHeapActivity.show(this);
                break;
            case R.id.iv_back:
                finish();
                break;

        }
    }
}


