package com.example.lmy.customview.RecyclerViewAddTitle.activity;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.widget.Toast;

import com.example.lmy.customview.Activity.BaseActivity;
import com.example.lmy.customview.RecyclerViewAddTitle.adapter.RecyclerAdapter;
import com.example.lmy.customview.R;

import java.util.ArrayList;

public class RecyclerViewActivity extends BaseActivity {
    private RecyclerView recyclerview;
    private RecyclerAdapter adapter;
    private LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);

    public static void show(Context context) {
        context.startActivity(new Intent(context, RecyclerViewActivity.class));
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recycler_view);
        recyclerview = findViewById(R.id.recyclerview);
        ArrayList list = new ArrayList();
        for (int i = 0; i < 100; i++) {
            list.add(String.valueOf(i));
        }

        adapter = new RecyclerAdapter(RecyclerViewActivity.this, list);
        recyclerview.setLayoutManager(linearLayoutManager);
        recyclerview.setAdapter(adapter);
        adapter.setItemOnClistener(new RecyclerAdapter.ItemOnClistener() {
            @Override
            public void itemClick(String s, int p) {
                Toast.makeText(RecyclerViewActivity.this, s, Toast.LENGTH_SHORT).show();
            }
        });
    }
}
