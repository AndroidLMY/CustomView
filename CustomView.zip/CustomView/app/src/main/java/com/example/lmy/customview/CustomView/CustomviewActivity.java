package com.example.lmy.customview.CustomView;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.example.lmy.customview.Activity.BaseActivity;
import com.example.lmy.customview.R;


public class CustomviewActivity extends BaseActivity {
    private CircleTextView textview;
    int anInt = 0;
    private Button buttonPanel;

    public static void show(Context context) {
        context.startActivity(new Intent(context, CustomviewActivity.class));
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.customview_activity);
        textview = findViewById(R.id.textview);
        textview.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (anInt % 2 == 0) {
                    textview.setmPaintNormalColor(Color.RED);
                    textview.setText("李");
                } else {
                    textview.setmPaintNormalColor(Color.BLUE);
                    textview.setText("张");
                }
                anInt = anInt + 1;
            }
        });

//        new Thread() {
//            @Override
//            public void run() {
//                super.run();
//                try {
//                    String re = LogisticsUtils.getOrderTracesByJson("708547687090");
//                    Log.d("GetData 查询物流返回的数据", re);
//                } catch (Exception e) {
//                    e.printStackTrace();
//                }
//
//            }
//        }.start();

    }


}
