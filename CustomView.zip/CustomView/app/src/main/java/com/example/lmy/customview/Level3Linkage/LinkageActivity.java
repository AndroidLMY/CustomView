package com.example.lmy.customview.Level3Linkage;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;

import com.example.lmy.customview.Activity.BaseActivity;
import com.example.lmy.customview.R;

public class LinkageActivity extends BaseActivity implements View.OnClickListener {
    private Spinner spinner1;
    private Spinner spinner2;
    private Spinner spinner3;
    private String province[] = new String[]{"江西", "湖南"};
    private int provinceindex;
    private String city[][] = {{"南昌", "赣州"}, {"南昌", "赣州"}};

    private TextView textview1;
    private TextView textview2;
    private TextView textview3;


    private String counstryside[][][] = {
            {
                    {
                            "青山湖区", "南昌县", "青山湖区", "南昌县", "青山湖区", "南昌县", "青山湖区", "南昌县"
                    },
                    {
                            "章贡区", "赣县", "章贡区", "赣县", "章贡区", "赣县", "章贡区", "赣县", "章贡区", "赣县"
                    }
            },
            {
                    {
                            "长沙县", "沙县", "长沙县", "沙县", "长沙县", "沙县", "长沙县", "沙县"
                    },
                    {
                            "湘潭县", "象限", "湘潭县", "象限", "湘潭县", "象限"
                    }
            }
    };
    ArrayAdapter<String> adapter1, adapter2, adapter3;

    public static void show(Context context) {
        context.startActivity(new Intent(context, LinkageActivity.class));
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_linkage);
        textview1 = findViewById(R.id.textview1);
        textview2 = findViewById(R.id.textview2);
        textview3 = findViewById(R.id.textview3);
        spinner1 = findViewById(R.id.spn);
        adapter1 = new ArrayAdapter<>(this, android.R.layout.simple_dropdown_item_1line, province);
        spinner1.setAdapter(adapter1);
        spinner2 = findViewById(R.id.city);
        adapter2 = new ArrayAdapter<>(this, android.R.layout.simple_dropdown_item_1line, city[0]);
        spinner2.setAdapter(adapter2);
        spinner3 = findViewById(R.id.counstryside);
        adapter3 = new ArrayAdapter<>(this, android.R.layout.simple_dropdown_item_1line, counstryside[0][0]);
        spinner3.setAdapter(adapter3);
        spinner1.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view,
                                       int position, long id) {
                // TODO Auto-generated method stub
                provinceindex = position;
                adapter2 = new ArrayAdapter<>(LinkageActivity.this, android.R.layout.simple_dropdown_item_1line, city[position]);
                spinner2.setAdapter(adapter2);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // TODO Auto-generated method stub

            }
        });

        spinner2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

            @Override
            public void onItemSelected(AdapterView<?> parent, View view,
                                       int position, long id) {
                // TODO Auto-generated method stub

                adapter3 = new ArrayAdapter<>(LinkageActivity.this, android.R.layout.simple_dropdown_item_1line, counstryside[provinceindex][position]);
                //adapter3.notifyDataSetChanged();
                spinner3.setAdapter(adapter3);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // TODO Auto-generated method stub
                //当时据为空的时候触发的
            }
        });
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.textview1:


                break;
            case R.id.textview2:

                break;
            case R.id.textview3:

                break;
        }
    }
}



