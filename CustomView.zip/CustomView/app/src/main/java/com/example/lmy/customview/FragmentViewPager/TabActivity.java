package com.example.lmy.customview.FragmentViewPager;

import android.content.Context;
import android.content.Intent;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.example.lmy.customview.Activity.BaseActivity;
import com.example.lmy.customview.R;

import java.util.ArrayList;
import java.util.List;

public class TabActivity extends BaseActivity {

    private TabLayout tab;
    private CustomViewPager viewpager;
    private FragmentAdapter fragmentAdapter;
    private Fragment1 fragment1;
    private Fragment2 fragment2;
    private Fragment3 fragment3;
    private List<Fragment> fragmentList;
    private String[] mTitles = new String[]{"测试1", "测试2", "测试3"};

    public static void show(Context context) {
        context.startActivity(new Intent(context, TabActivity.class));
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tab);
        tab = findViewById(R.id.tab);
        viewpager = findViewById(R.id.viewpager);
        init();
    }

    private void init() {
        fragmentList = new ArrayList<>();
        fragment1 = new Fragment1();
        fragment2 = new Fragment2();
        fragment3 = new Fragment3();
        fragmentList.add(fragment1);
        fragmentList.add(fragment2);
        fragmentList.add(fragment3);
        fragmentAdapter = new FragmentAdapter(getSupportFragmentManager(), fragmentList, mTitles);
        viewpager.setAdapter(fragmentAdapter);
        viewpager.setScanScroll(true);//设置viewpager是否可以滑动
        viewpager.setOffscreenPageLimit(3);
        //将TabLayout与ViewPager绑定在一起
        tab.setupWithViewPager(viewpager);


    }
}
