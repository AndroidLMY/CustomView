package com.example.lmy.customview.MPChart.Activity;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.lmy.customview.R;
import com.example.lmy.customview.MPChart.Adapter.RecyclerviewHAdapter;

import java.util.ArrayList;

/**
 * 功能:
 * 自定义横向堆积图
 *
 * @author :limingyang
 * @create ：2019/5/23 13:02
 * @created by android studiuo
 */
public class RecyclerViewHeapActivity extends AppCompatActivity {
    private RecyclerView recyclerview;
    private LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
    private RecyclerviewHAdapter recyclerviewHAdapter;
    private ArrayList<String> list1 = new ArrayList();
    private ArrayList<String> list2 = new ArrayList();
    private ArrayList<String> list3 = new ArrayList();
    private ImageView ivBack;
    private TextView tvTitle;

    public static void show(Context context) {
        context.startActivity(new Intent(context, RecyclerViewHeapActivity.class));
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recycler_view_heap);
        recyclerview = findViewById(R.id.recyclerview);
        ivBack = findViewById(R.id.iv_back);
        tvTitle = findViewById(R.id.tv_title);
        ivBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        tvTitle.setText("自定义横向堆积图");
        for (int i = 0; i < 10; i++) {
            list1.add(String.valueOf(Math.random() * 100));
            list2.add(String.valueOf(Math.random() * 100));
            list3.add(String.valueOf(Math.random() * 100));
        }
        if (recyclerviewHAdapter == null) {
            recyclerviewHAdapter = new RecyclerviewHAdapter(this, list1, list2, list3);
            recyclerview.setLayoutManager(linearLayoutManager);
            recyclerview.setAdapter(recyclerviewHAdapter);
        } else {
            recyclerviewHAdapter.notifyDataSetChanged();
        }

    }
}
