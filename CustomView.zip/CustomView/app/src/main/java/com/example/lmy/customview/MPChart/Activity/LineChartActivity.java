package com.example.lmy.customview.MPChart.Activity;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.lmy.customview.R;
import com.example.lmy.customview.MPChart.Utils.LineChartMannager;
import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.data.Entry;

import java.util.ArrayList;

/**
 * 功能:
 * 折线统计图带背景 和不带背景 自定义x轴 自定义缩放
 *
 * @author :limingyang
 * @create ：2019/4/11 16:33
 * @created by android studiuo
 */
public class LineChartActivity extends AppCompatActivity {
    private LineChart lineChartbg;
    private LineChart lineChartNobg;
    private ArrayList<String> xlist = new ArrayList<>();
    private ImageView ivBack;
    private TextView tvTitle;

    public static void show(Context context) {
        context.startActivity(new Intent(context, LineChartActivity.class));
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_zhe_xian_tu);
        lineChartbg = findViewById(R.id.lineChartbg);
        lineChartNobg = findViewById(R.id.lineChartNobg);
        ivBack = findViewById(R.id.iv_back);
        tvTitle = findViewById(R.id.tv_title);
        ivBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        tvTitle.setText("折线统计图");
        ArrayList<String> namelist = new ArrayList<>();
        namelist.add("经销商A");
        namelist.add("经销商B");
        namelist.add("经销商C");
        namelist.add("经销商D");
        ArrayList<ArrayList<Entry>> list = new ArrayList<>();
        ArrayList<Entry> values;
        for (int i = 0; i < 2; i++) {
            //这一层循环用于遍历一共有几条线的数据
            values = new ArrayList<>();
            for (int k = 0; k < 20; k++) {
                values.add(new Entry(k, new Double(Math.random() * 100).intValue()));
            }
            list.add(values);
        }
        for (int i = 1; i <= 20; i++) {
            xlist.add(String.valueOf(i).concat("月"));
            //自定义x轴的数据
        }
        LineChartMannager.getInstance().initBackground(this, lineChartbg, list, namelist, xlist, 10, 100, 10);
        LineChartMannager.getInstance().initNoBackground(this, lineChartNobg, list, namelist, xlist, 10, 100, 10);

    }

}
