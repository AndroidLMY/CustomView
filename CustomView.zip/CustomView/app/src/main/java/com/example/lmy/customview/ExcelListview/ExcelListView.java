package com.example.lmy.customview.ExcelListview;

import android.content.Context;
import android.content.Intent;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Toast;

import com.example.lmy.customview.Activity.BaseActivity;
import com.example.lmy.customview.R;

import java.util.ArrayList;

public class ExcelListView extends BaseActivity {
    private StockListAdapter mAdapter;
    private HVScrollViews hvScrollView;
    private ArrayList<StockDataInfo> stockDataInfoList;

    public static void show(Context context) {
        context.startActivity(new Intent(context, ExcelListView.class));
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_excel_list_view);
        hvScrollView = findViewById(R.id.hv_scrollview);
        stockDataInfoList = new ArrayList<>();
        for (int i = 0; i < 1; i++) {
            StockDataInfo stockDataInfo = new StockDataInfo();
            stockDataInfo.setStockName("补");
            stockDataInfo.setStockCode("600000");
            stockDataInfo.setPriceLastest("补料单");
            stockDataInfo.setPriceOffsetRate("郑州中原国贸经销商");
            stockDataInfo.setPriceHigh("王大锤");
            stockDataInfo.setSelect(true);
            stockDataInfo.setPriceLow("橱柜");
            stockDataInfo.setPriceOpen("美克");
            stockDataInfoList.add(stockDataInfo);
        }
        //定义顶部栏
        hvScrollView.setHeaderListData(new String[]{"类型"},new String[]{"类型","经销商名称", "C端客户", "产品类型", "系列", "操作"});
        mAdapter = new StockListAdapter(this, stockDataInfoList, R.layout.item_layout);
        hvScrollView.setAdapter(mAdapter);
        //点击列表item
        hvScrollView.setOnItemClick(new HVScrollViews.OnItemClickedListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if (stockDataInfoList.get(position).isSelect()) {
                    stockDataInfoList.get(position).setSelect(false);
                } else {
                    stockDataInfoList.get(position).setSelect(true);
                }
                mAdapter.notifyDataSetChanged();
                Toast.makeText(ExcelListView.this, position + "", Toast.LENGTH_SHORT).show();
            }
        });
        //点击头部按钮
        hvScrollView.setOnHeaderClickedListener(new HVScrollViews.OnHeaderClickedListener() {
            @Override
            public void onHeadViewClick(String string) {
                Toast.makeText(ExcelListView.this, string, Toast.LENGTH_SHORT).show();
            }
        });

        hvScrollView.setOnLoadMoreListener(new HVScrollViews.OnLoadMoreListener() {
            @Override
            public void onLoadingMore() {

                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            Thread.sleep(1000);
                            handler.sendEmptyMessage(5);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    }
                }).start();
            }
        });
    }
    android.os.Handler handler = new android.os.Handler(new android.os.Handler.Callback() {
        @Override
        public boolean handleMessage(Message msg) {
            if (msg.what == 5) {
                for (int i = 0; i < 10; i++) {
                    StockDataInfo stockDataInfo = new StockDataInfo();
                    stockDataInfo.setStockName("补190407-001-01" + i + "A");
                    stockDataInfo.setSelect(false);
                    stockDataInfo.setStockCode("600000");
                    stockDataInfo.setPriceLastest("补料单");
                    stockDataInfo.setPriceOffsetRate("郑州中原国贸经销商");
                    stockDataInfo.setPriceHigh("王大锤");
                    stockDataInfo.setPriceLow("橱柜");
                    stockDataInfo.setPriceOpen("美克");
                    stockDataInfoList.add(stockDataInfo);
                    mAdapter.notifyDataSetChanged();
                }
                hvScrollView.onLoadingComplete();
            }
            return false;
        }
    });
}
