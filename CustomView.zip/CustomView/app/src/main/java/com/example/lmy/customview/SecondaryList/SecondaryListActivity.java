package com.example.lmy.customview.SecondaryList;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseExpandableListAdapter;
import android.widget.ExpandableListView;
import android.widget.ImageView;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.lmy.customview.Activity.BaseActivity;
import com.example.lmy.customview.R;

public class SecondaryListActivity extends BaseActivity {
    //View
    private ExpandableListViewForScrollView expandableListView;
    private ExpandableAdapter adapter;


    private ScrollView scrollview;
    //Model：定义的数据
    private String[] groups = {"客厅", "厨房", "卧室"};
    //注意，字符数组不要写成{{"A1,A2,A3,A4"}, {"B1,B2,B3,B4，B5"}, {"C1,C2,C3,C4"}}
    private Integer[][] childs = {{R.drawable.chess1,}, {R.drawable.chess1, R.drawable.chess1}, {R.drawable.chess1, R.drawable.chess1, R.drawable.chess1, R.drawable.chess1}};


    public static void show(Context context) {
        context.startActivity(new Intent(context, SecondaryListActivity.class));
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_secondary_list);
        expandableListView = findViewById(R.id.elv);
        adapter = new ExpandableAdapter(this, groups, childs);
        expandableListView.setAdapter(adapter);
        scrollview = (ScrollView) findViewById(R.id.scrollview);
        scrollview.setFocusable(true);
        scrollview.setFocusableInTouchMode(true);
        scrollview.requestFocus();
        expandableListView.setGroupIndicator(null);//去掉默认显示的箭头
        for (int i = 0; i < adapter.getGroupCount(); i++) {
            expandableListView.expandGroup(i);
        }
        //组点击无效果
        expandableListView.setOnGroupClickListener(new ExpandableListView.OnGroupClickListener() {

            @Override
            public boolean onGroupClick(ExpandableListView parent, View v, int groupPosition, long id) {
                return true;
            }
        });

        expandableListView.setOnChildClickListener(new ExpandableListView.OnChildClickListener() {
            @Override
            public boolean onChildClick(ExpandableListView parent, View v, int groupPosition, int childPosition, long id) {
                Toast.makeText(SecondaryListActivity.this, childs[groupPosition][childPosition], Toast.LENGTH_SHORT).show();
                return false;
            }
        });
    }
}
