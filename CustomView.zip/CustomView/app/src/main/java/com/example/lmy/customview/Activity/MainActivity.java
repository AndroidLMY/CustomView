package com.example.lmy.customview.Activity;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.lmy.customview.BGAPhotoPicker.activity.BGAPickerActivity;
import com.example.lmy.customview.CustomView.CustomviewActivity;
import com.example.lmy.customview.CustomView.MyDialog;
import com.example.lmy.customview.ExcelListview.ExcelListView;
import com.example.lmy.customview.FragmentViewPager.TabActivity;
import com.example.lmy.customview.Level3Linkage.LinkageActivity;
import com.example.lmy.customview.OkHttp.OkHttpTestActivity;
import com.example.lmy.customview.R;
import com.example.lmy.customview.RecyclerViewAddTitle.activity.RecyclerViewActivity;
import com.example.lmy.customview.RecyclerviewCheck.CheckActivity;
import com.example.lmy.customview.SecondaryList.SecondaryListActivity;
import com.example.lmy.customview.MPChart.Activity.MainMPChartActivity;
import com.example.lmy.customview.TimeRecyclerview.test2.Time2Activity;
import com.example.lmy.customview.Utils.PermissionUtils;
import com.example.lmy.customview.WebView.WebViewActivity;

public class MainActivity extends BaseActivity implements View.OnClickListener {

    private Button btView, btBga, btDialog, btRecyclerview, btStatistics, secondarylistBt, checkRecyclerview, viewpagerFragment, btExcel, btTime, btLinkage, okhttp, updata, webview;
    String[] perms = {
            Manifest.permission.READ_CALENDAR,//日历权限
            Manifest.permission.CAMERA,//相机
            Manifest.permission.ACCESS_FINE_LOCATION,//位置
            Manifest.permission.READ_PHONE_STATE,//手机
            Manifest.permission.WRITE_EXTERNAL_STORAGE,//存储卡
    };
    private ImageView ivBack;
    private TextView tvTitle;


    public static void show(Context context) {
        context.startActivity(new Intent(context, MainActivity.class));
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        PermissionUtils.getInstance().methodRequiresTwoPermission(MainActivity.this, perms);
        initViews();
    }

    @Override
    public void initViews() {
        btView = findViewById(R.id.bt_view);
        btBga = findViewById(R.id.bt_bga);
        btDialog = findViewById(R.id.bt_dialog);
        btRecyclerview = findViewById(R.id.bt_recyclerview);
        btStatistics = findViewById(R.id.bt_statistics);
        secondarylistBt = findViewById(R.id.secondarylist_bt);
        checkRecyclerview = findViewById(R.id.check_recyclerview);
        btTime = findViewById(R.id.bt_time);
        okhttp = findViewById(R.id.okhttp);
        updata = findViewById(R.id.updata);
        viewpagerFragment = findViewById(R.id.viewpager_fragment);
        btExcel = findViewById(R.id.bt_excel);
        btLinkage = findViewById(R.id.bt_linkage);
        webview = findViewById(R.id.webview);
        ivBack = findViewById(R.id.iv_back);
        tvTitle = findViewById(R.id.tv_title);
        initData();
    }

    @Override
    public void initData() {
        tvTitle.setText("调试Demo");
        ivBack.setVisibility(View.GONE);
        initListener();
    }

    @Override
    public void initListener() {
        btBga.setOnClickListener(this);
        btView.setOnClickListener(this);
        btDialog.setOnClickListener(this);
        btRecyclerview.setOnClickListener(this);
        btStatistics.setOnClickListener(this);
        secondarylistBt.setOnClickListener(this);
        checkRecyclerview.setOnClickListener(this);
        viewpagerFragment.setOnClickListener(this);
        btExcel.setOnClickListener(this);
        btTime.setOnClickListener(this);
        btLinkage.setOnClickListener(this);
        okhttp.setOnClickListener(this);
        updata.setOnClickListener(this);
        webview.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.bt_view:
                CustomviewActivity.show(this);
                break;
            case R.id.bt_bga:
                BGAPickerActivity.show(this);
                break;
            case R.id.bt_dialog:
                showDialog();
                break;
            case R.id.bt_statistics:
                MainMPChartActivity.show(this);
                break;
            case R.id.bt_recyclerview:
                RecyclerViewActivity.show(this);
                break;
            case R.id.secondarylist_bt:
                SecondaryListActivity.show(this);
                break;
            case R.id.check_recyclerview:
                CheckActivity.show(this);
                break;
            case R.id.viewpager_fragment:
                TabActivity.show(this);
                break;
            case R.id.bt_excel:
                ExcelListView.show(this);
                break;
            case R.id.bt_time:
                Time2Activity.show(this);
                break;
            case R.id.bt_linkage:
                LinkageActivity.show(this);
                break;
            case R.id.okhttp:
                OkHttpTestActivity.show(this);
                break;
            case R.id.updata:
                UpDataActivity.show(this);
                break;
            case R.id.webview:
                WebViewActivity.show(this);
                break;
        }
    }

    private void showDialog() {
        final MyDialog myDialog = new MyDialog(this);
        myDialog.setTitle("这是一个自定义的dialog？")
                .setMessage("这是内容")
                .setDialogCancelable(false)
                .setPositiveButton("确认", new MyDialog.OnMyDialogButtonClickListener() {
                    @Override
                    public void onClick() {
                        myDialog.dismiss();
                    }
                })
                .setNegativeButton("取消", new MyDialog.OnMyDialogButtonClickListener() {
                    @Override
                    public void onClick() {
                        myDialog.dismiss();
                    }
                })
                .show();
    }
}
